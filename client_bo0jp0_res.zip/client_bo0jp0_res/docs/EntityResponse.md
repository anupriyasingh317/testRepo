# CorporateActionsApiV1.EntityResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **String** |  | [optional] 
**statusCode** | **String** |  | [optional] 
