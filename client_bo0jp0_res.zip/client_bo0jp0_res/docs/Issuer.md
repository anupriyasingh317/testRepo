# CorporateActionsApiV1.Issuer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**tickerSymbol** | **String** |  | [optional] 
**id** | **String** | Issuer Id | [optional] 
**ISIN** | **String** |  | [optional] 
