# CorporateActionsApiV1.ActionDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | [optional] 
**splitRatio** | **String** |  | [optional] 
