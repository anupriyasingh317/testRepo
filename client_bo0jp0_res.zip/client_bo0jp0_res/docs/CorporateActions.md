# CorporateActionsApiV1.CorporateActions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exDate** | **String** |  | [optional] 
**affectedSecurities** | [**AffectedSecurities**](AffectedSecurities.md) |  | [optional] 
**recordDate** | **String** |  | [optional] 
**id** | **String** | Corporate Actions Id | [optional] 
**type** | **String** |  | [optional] 
**paymentDate** | **String** |  | [optional] 
**issuer** | [**Issuer**](Issuer.md) |  | [optional] 
